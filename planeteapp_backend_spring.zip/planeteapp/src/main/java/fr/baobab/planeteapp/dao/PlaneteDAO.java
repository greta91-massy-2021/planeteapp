package fr.baobab.planeteapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.baobab.planeteapp.model.Planete;

public interface PlaneteDAO extends JpaRepository<Planete, Long>{

}
