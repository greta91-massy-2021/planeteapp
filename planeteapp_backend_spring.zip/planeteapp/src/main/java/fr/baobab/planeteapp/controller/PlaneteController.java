package fr.baobab.planeteapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import fr.baobab.planeteapp.dao.PlaneteDAO;
import fr.baobab.planeteapp.model.Planete;

@RestController
public class PlaneteController {
	@Autowired
	PlaneteDAO planeteDAO;
	
	@GetMapping("/planetes")
	public ResponseEntity<List<Planete>> getPlanetes(){
		List<Planete> planetes = planeteDAO.findAll();
		if (planetes.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(planetes);
	}
	
	@GetMapping("/planetes/{id}")
	public ResponseEntity<Planete> getPlanete(@PathVariable Long id){
		Optional<Planete> optPlanete = planeteDAO.findById(id);
		if (!optPlanete.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(optPlanete.get());
	}
	
	@PostMapping("/planetes")
	public ResponseEntity<Planete> createPlanete(@RequestBody Planete planete){
		try {
			Planete res = planeteDAO.save(planete);
			return ResponseEntity.ok(res);
		}
		catch(Exception ex) {
			return ResponseEntity.notFound().build();
		}
	}
	
	@PutMapping("/planetes/{id}")
	public ResponseEntity<Planete> editPlanete(@PathVariable long id, @RequestBody Planete planete){
		try {
			Planete res = planeteDAO.save(planete);
			return ResponseEntity.ok(res);
		}
		catch(Exception ex) {
			return ResponseEntity.notFound().build();
		}
	}
	@DeleteMapping("/planetes/{id}")
	public ResponseEntity<Planete> deletePlanete(@PathVariable long id){
		try {
			Planete planete = planeteDAO.findById(id).get();
			if(null != planete) {
				planeteDAO.delete(planete);
				return ResponseEntity.ok(planete);
			}
			else {
				return ResponseEntity.notFound().build();
			}
		}
		catch(Exception ex) {
			return ResponseEntity.notFound().build();
		}
	}
}
