SET GLOBAL max_allowed_packet=16000000;
insert into planete (name, distance) values ('Mercure',58),('Vénus',108);
